import { Phone, MessageSquare, Clock, MapPin, Send } from 'lucide-react';
import { motion } from 'motion/react';

export default function ContactPage() {
  return (
    <div className="flex flex-col lg:flex-row gap-12 lg:gap-16 items-start pb-10 max-w-6xl mx-auto w-full">
      <div className="flex-1 w-full lg:max-w-[60%]">
        <header className="mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center justify-center w-16 h-16 bg-neutral-100 rounded-full mb-6"
          >
            <Phone size={32} className="text-neutral-900" />
          </motion.div>
          <motion.h1 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl lg:text-6xl font-black text-neutral-900 tracking-tight mb-6"
          >
            Contact <br className="hidden sm:block" /> Vipin Cement Agency
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="text-lg md:text-xl text-neutral-600 font-medium"
          >
            Have an enquiry or need a bulk order quote? Get in touch with us today. We're ready to assist you.
          </motion.p>
        </header>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 mb-12">
          {/* Call Now Card */}
          <a 
            href="tel:8239433868"
            className="bg-neutral-900 hover:bg-neutral-800 text-white rounded-3xl p-8 shadow-xl shadow-neutral-900/10 transition-transform hover:-translate-y-1 active:translate-y-0 group relative overflow-hidden"
          >
            <div className="absolute -right-6 -top-6 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
            <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform backdrop-blur-sm border border-white/10">
              <Phone size={24} className="text-white" />
            </div>
            <p className="text-sm text-neutral-400 mb-2 font-bold uppercase tracking-wider">Call Now</p>
            <p className="text-3xl font-black tracking-tight">8239433868</p>
          </a>

          {/* WhatsApp Card */}
          <a 
            href="https://wa.me/918239433868" 
            target="_blank" 
            rel="noopener noreferrer"
            className="bg-[#25D366] hover:bg-[#20bd5a] text-white rounded-3xl p-8 shadow-xl shadow-[#25D366]/20 transition-transform hover:-translate-y-1 active:translate-y-0 group relative overflow-hidden"
          >
            <div className="absolute -right-6 -top-6 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
            <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform backdrop-blur-sm border border-white/20">
              <MessageSquare size={24} className="text-white" />
            </div>
            <p className="text-sm text-green-100 mb-2 font-bold uppercase tracking-wider">WhatsApp</p>
            <p className="text-3xl font-black tracking-tight">8239433868</p>
          </a>
        </div>

        <div className="bg-white rounded-[2rem] p-8 md:p-10 border border-neutral-200 shadow-xl shadow-neutral-100/50">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-10 h-10 bg-neutral-100 rounded-full flex items-center justify-center">
              <Send size={18} className="text-neutral-900" />
            </div>
            <h3 className="text-2xl font-bold text-neutral-900">Business Enquiry</h3>
          </div>
          
          <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-bold text-neutral-700 mb-2">Full Name</label>
                <input type="text" id="name" className="w-full rounded-2xl border-neutral-200 bg-neutral-50 px-5 py-4 text-neutral-900 focus:border-neutral-900 focus:ring-0 outline-none border-2 transition-colors font-medium placeholder:text-neutral-400" placeholder="John Doe" />
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-bold text-neutral-700 mb-2">Phone Number</label>
                <input type="tel" id="phone" className="w-full rounded-2xl border-neutral-200 bg-neutral-50 px-5 py-4 text-neutral-900 focus:border-neutral-900 focus:ring-0 outline-none border-2 transition-colors font-medium placeholder:text-neutral-400" placeholder="+91 00000 00000" />
              </div>
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-bold text-neutral-700 mb-2">Your Requirements</label>
              <textarea id="message" rows={4} className="w-full rounded-2xl border-neutral-200 bg-neutral-50 px-5 py-4 text-neutral-900 focus:border-neutral-900 focus:ring-0 outline-none border-2 transition-colors font-medium placeholder:text-neutral-400 resize-none" placeholder="I am looking for..."></textarea>
            </div>
            <button className="w-full bg-neutral-900 hover:bg-neutral-800 text-white font-bold py-5 px-6 rounded-2xl transition-all shadow-lg hover:shadow-xl active:scale-[0.98] mt-2">
              Submit Enquiry
            </button>
          </form>
        </div>
      </div>

      <div className="flex-1 w-full lg:max-w-[35%] space-y-6 lg:mt-48">
        <div className="bg-neutral-50 rounded-[2rem] p-8 border border-neutral-200">
          <div className="flex flex-col gap-6">
            <div className="w-12 h-12 bg-white rounded-2xl border border-neutral-200 flex items-center justify-center shadow-sm">
              <Clock size={20} className="text-neutral-900" />
            </div>
            <div>
              <h4 className="text-xl font-bold text-neutral-900 mb-4">Working Hours</h4>
              <ul className="text-neutral-600 font-medium space-y-4">
                <li className="flex items-center justify-between">
                  <span>Mon - Sat</span> 
                  <span className="text-neutral-900 bg-white px-3 py-1 rounded-lg border border-neutral-200 shadow-sm text-sm">9:00 AM - 7:00 PM</span>
                </li>
                <li className="flex items-center justify-between border-t border-neutral-200 pt-4">
                  <span>Sunday</span> 
                  <span className="text-neutral-500 bg-neutral-100 px-3 py-1 rounded-lg border border-neutral-200 text-sm">Closed</span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-neutral-50 rounded-[2rem] p-8 border border-neutral-200">
          <div className="flex flex-col gap-6">
            <div className="w-12 h-12 bg-white rounded-2xl border border-neutral-200 flex items-center justify-center shadow-sm">
              <MapPin size={20} className="text-neutral-900" />
            </div>
            <div>
              <h4 className="text-xl font-bold text-neutral-900 mb-4">Our Location</h4>
              <p className="text-neutral-600 font-medium leading-relaxed mb-6">
                [Editable: Shop No. / Street Address]<br/>
                [Editable: City, State, ZIP]
              </p>
              <a href="/" className="inline-flex items-center justify-center w-full bg-white hover:bg-neutral-100 text-neutral-900 font-bold py-3 px-6 rounded-xl transition-colors border border-neutral-200 shadow-sm">
                View on Map
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
