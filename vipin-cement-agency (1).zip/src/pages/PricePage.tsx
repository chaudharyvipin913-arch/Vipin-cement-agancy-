import { Info, Tag, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

export default function PricePage() {
  return (
    <div className="max-w-4xl mx-auto pb-12">
      <header className="text-center mb-16">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-neutral-100 rounded-full mb-6"
        >
          <Tag size={32} className="text-neutral-900" />
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-5xl lg:text-6xl font-black text-neutral-900 tracking-tight mb-6"
        >
          Birla Perfect Cement <br className="hidden sm:block" />
          <span className="text-neutral-400">– Rate</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-lg md:text-xl text-neutral-600 font-medium"
        >
          Current market rate for our premium cement offering.
        </motion.p>
      </header>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-white rounded-[2.5rem] p-8 md:p-16 shadow-2xl shadow-neutral-200/50 border border-neutral-200 text-center relative overflow-hidden"
      >
        {/* Decorative background elements */}
        <div className="absolute -top-32 -right-32 w-80 h-80 bg-neutral-100 rounded-full blur-3xl opacity-60 pointer-events-none"></div>
        <div className="absolute -bottom-32 -left-32 w-80 h-80 bg-neutral-100 rounded-full blur-3xl opacity-60 pointer-events-none"></div>

        <div className="relative z-10 flex flex-col items-center">
          <div className="inline-flex items-center justify-center px-6 py-2 bg-neutral-100 text-neutral-900 rounded-full mb-10 border border-neutral-200 shadow-sm font-bold tracking-widest text-sm uppercase">
            Today's Price
          </div>

          <h2 className="text-2xl md:text-3xl font-black text-neutral-400 mb-4 tracking-tight">
            Birla Perfect Cement
          </h2>
          
          <div className="flex items-start justify-center text-neutral-900 mb-12">
            <span className="text-5xl md:text-6xl font-black mt-3 mr-2">₹</span>
            <span className="text-9xl md:text-[12rem] font-black tracking-tighter leading-none">350</span>
            <span className="text-2xl text-neutral-500 font-bold self-end mb-6 ml-4">/ bag</span>
          </div>

          <div className="flex items-start gap-4 max-w-2xl mx-auto bg-neutral-50 p-6 rounded-2xl text-left border border-neutral-200 mb-12 shadow-inner">
            <div className="bg-white p-2 rounded-xl shadow-sm shrink-0 border border-neutral-100">
              <Info className="text-neutral-900" size={24} />
            </div>
            <p className="text-base text-neutral-700 font-medium leading-relaxed">
              <strong className="text-neutral-900 font-bold">Note:</strong> For the latest price and availability, please contact Vipin Cement Agency directly. Rates may be subject to market fluctuations and bulk order discounts.
            </p>
          </div>

          <Link 
            to="/contact" 
            className="inline-flex items-center justify-center gap-3 bg-neutral-900 hover:bg-neutral-800 text-white font-bold py-5 px-10 rounded-2xl transition-all hover:-translate-y-1 shadow-xl shadow-neutral-900/20 text-lg w-full sm:w-auto min-w-[280px] active:scale-[0.98]"
          >
            Contact to Order
            <ArrowRight size={20} strokeWidth={2.5} />
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
