import { MapPin, Navigation, Building2 } from 'lucide-react';
import { motion } from 'motion/react';

export default function LocationPage() {
  return (
    <div className="flex flex-col gap-12 lg:gap-16">
      <header className="text-center max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-neutral-100 rounded-full mb-6"
        >
          <Building2 size={32} className="text-neutral-900" />
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-5xl lg:text-6xl font-black text-neutral-900 tracking-tight mb-6"
        >
          Vipin Cement Agency <br className="hidden sm:block" />
          <span className="text-neutral-400">– Location</span>
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-lg md:text-xl text-neutral-600 font-medium"
        >
          Visit our agency to explore premium cement options for your next construction project.
        </motion.p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
        {/* Visual / Image Section */}
        <div className="lg:col-span-7 rounded-[2rem] overflow-hidden shadow-2xl shadow-neutral-200/50 aspect-4/3 sm:aspect-video lg:aspect-4/3 relative group">
          <img 
            src="/assets/aistudio/IMG_20260910_143321.jpg" 
            alt="Vipin Cement Agency Shop Front" 
            className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-1000 ease-out"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/80 via-neutral-900/20 to-transparent flex items-end p-8 md:p-10">
            <div className="text-white">
              <h3 className="text-2xl font-bold mb-2">Vipin Cement Agency</h3>
              <p className="text-white/80 font-medium tracking-wide text-sm uppercase">Building trust with every bag</p>
            </div>
          </div>
        </div>

        {/* Address & Map Info */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          <div className="bg-white rounded-3xl p-8 md:p-10 border border-neutral-200 shadow-xl shadow-neutral-100/50 relative overflow-hidden">
            {/* Decorative bg accent */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-neutral-50 rounded-bl-[100px] -z-10"></div>
            
            <div className="flex flex-col gap-8">
              <div>
                <div className="inline-flex items-center justify-center w-12 h-12 bg-neutral-100 text-neutral-900 rounded-xl mb-6">
                  <MapPin size={24} />
                </div>
                <h2 className="text-2xl font-bold text-neutral-900 mb-6">Store Address</h2>
                <div className="text-neutral-600 space-y-2 text-lg leading-relaxed">
                  <p className="font-bold text-neutral-900">Vipin Cement Agency</p>
                  <p className="text-neutral-500 border-b border-neutral-100 pb-2 border-dashed">[Editable: Shop No. / Street Address]</p>
                  <p className="text-neutral-500 border-b border-neutral-100 pb-2 border-dashed">[Editable: Area / Landmark]</p>
                  <p className="text-neutral-500">[Editable: City, State, ZIP]</p>
                </div>
              </div>

              <a 
                href="#" 
                onClick={(e) => e.preventDefault()}
                className="inline-flex items-center justify-center gap-2 w-full bg-neutral-900 hover:bg-neutral-800 text-white font-bold py-4 px-6 rounded-2xl transition-all shadow-lg hover:shadow-xl active:scale-[0.98]"
              >
                <Navigation size={20} />
                Get Directions
              </a>
            </div>
          </div>

          <div className="bg-neutral-100 rounded-3xl p-8 border border-neutral-200 flex flex-col items-center justify-center text-center aspect-video relative overflow-hidden group cursor-pointer shadow-inner">
            <div className="absolute inset-0 bg-neutral-900/5 flex items-center justify-center z-10 transition-colors group-hover:bg-neutral-900/10">
              <div className="bg-white px-6 py-3 rounded-full shadow-lg shadow-neutral-200/50 text-sm font-bold flex items-center gap-2 text-neutral-800 transform group-hover:-translate-y-1 transition-transform">
                <MapPin size={16} className="text-neutral-900" />
                [Placeholder: Google Maps Embed]
              </div>
            </div>
            {/* Faux map background pattern */}
            <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', backgroundSize: '30px 30px' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
}
