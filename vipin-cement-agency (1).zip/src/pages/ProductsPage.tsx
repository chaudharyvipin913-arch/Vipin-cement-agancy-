import { ArrowRight, CheckCircle2, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

export default function ProductsPage() {
  const products = [
    {
      id: 'ultratech',
      name: 'UltraTech Cement',
      tagline: 'The Engineer\'s Choice',
      image: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&q=80&w=800',
      description: 'Premium quality cement offering high strength and durability for residential and commercial construction. Known for superior reliability and consistent performance under extreme conditions.',
      features: ['High compressive strength', 'Excellent durability', 'Ideal for all concrete applications']
    },
    {
      id: 'birla-perfect',
      name: 'Birla Perfect Cement',
      tagline: 'Strength & Perfection',
      image: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?auto=format&fit=crop&q=80&w=800',
      description: 'Advanced formulation designed to resist cracks and weather elements. Birla Perfect delivers a flawless finish and robust structural integrity for your building\'s foundation and roofing.',
      features: ['Crack-resistant technology', 'Smooth premium finish', 'Optimal setting time']
    }
  ];

  return (
    <div className="flex flex-col gap-12 lg:gap-16 pb-8">
      <header className="text-center max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-neutral-100 rounded-full mb-6"
        >
          <ShieldCheck size={32} className="text-neutral-900" />
        </motion.div>
        <motion.h1 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-5xl lg:text-6xl font-black text-neutral-900 tracking-tight mb-6"
        >
          Our Cement
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-lg md:text-xl text-neutral-600 font-medium"
        >
          We stock the industry's most trusted brands to ensure your construction stands the test of time.
        </motion.p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 max-w-6xl mx-auto w-full">
        {products.map((product, index) => (
          <motion.div 
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-[2rem] overflow-hidden shadow-xl shadow-neutral-200/40 border border-neutral-100 flex flex-col group hover:shadow-2xl hover:-translate-y-1 transition-all duration-300"
          >
            <div className="aspect-[4/3] overflow-hidden relative bg-neutral-100">
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out mix-blend-multiply"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-900/90 via-neutral-900/30 to-transparent"></div>
              <div className="absolute bottom-0 left-0 w-full p-8">
                <span className="inline-block px-4 py-1.5 bg-white/20 backdrop-blur-md text-white text-xs font-bold uppercase tracking-widest rounded-full mb-4 border border-white/20">
                  Premium
                </span>
                <h2 className="text-3xl font-black text-white mb-2 tracking-tight">{product.name}</h2>
                <p className="text-white/80 font-medium">{product.tagline}</p>
              </div>
            </div>
            
            <div className="p-8 lg:p-10 flex flex-col flex-1 bg-white">
              <p className="text-neutral-600 text-lg leading-relaxed mb-8 font-medium">
                {product.description}
              </p>
              
              <ul className="space-y-4 mb-10 flex-1">
                {product.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-4 text-neutral-800 font-medium">
                    <div className="bg-neutral-100 rounded-full p-1 mt-0.5 shrink-0">
                      <CheckCircle2 size={16} className="text-neutral-900" strokeWidth={3} />
                    </div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <Link 
                to="/contact" 
                className="inline-flex items-center justify-between w-full bg-neutral-50 hover:bg-neutral-100 border-2 border-neutral-100 text-neutral-900 font-bold py-5 px-6 rounded-2xl transition-colors group/btn"
              >
                <span>Contact Us for Price</span>
                <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center shadow-sm group-hover/btn:scale-110 transition-transform">
                  <ArrowRight size={16} className="text-neutral-900" strokeWidth={2.5} />
                </div>
              </Link>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
