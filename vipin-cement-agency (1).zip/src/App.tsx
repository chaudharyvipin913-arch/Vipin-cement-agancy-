/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import LocationPage from './pages/LocationPage';
import ProductsPage from './pages/ProductsPage';
import ContactPage from './pages/ContactPage';
import PricePage from './pages/PricePage';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<LocationPage />} />
          <Route path="products" element={<ProductsPage />} />
          <Route path="contact" element={<ContactPage />} />
          <Route path="price" element={<PricePage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
