import { Link, Outlet, useLocation } from 'react-router-dom';
import { MapPin, Package, Phone, TrendingUp, Menu, X, Hammer } from 'lucide-react';
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export default function Layout() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  // Scroll to top on route change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location.pathname]);

  const navLinks = [
    { name: 'Location', path: '/', icon: MapPin },
    { name: 'Our Cement', path: '/products', icon: Package },
    { name: 'Rate', path: '/price', icon: TrendingUp },
    { name: 'Contact', path: '/contact', icon: Phone },
  ];

  const closeMenu = () => setIsMobileMenuOpen(false);

  return (
    <div className="min-h-screen flex flex-col font-sans text-neutral-800 bg-neutral-50 selection:bg-amber-200 selection:text-neutral-900">
      {/* Header */}
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-50 shadow-sm shadow-neutral-200/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-neutral-900 rounded-lg flex items-center justify-center text-white shrink-0 group-hover:bg-amber-500 transition-colors duration-300">
                <Hammer size={20} strokeWidth={2.5} />
              </div>
              <div className="flex flex-col">
                <span className="font-black text-xl leading-none text-neutral-900 uppercase tracking-tight">
                  Vipin
                </span>
                <span className="text-[10px] font-bold text-neutral-500 uppercase tracking-[0.2em] mt-0.5">
                  Cement Agency
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-1 lg:space-x-2">
              {navLinks.map((link) => {
                const isActive = location.pathname === link.path;
                return (
                  <Link
                    key={link.path}
                    to={link.path}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold transition-all duration-200 ${
                      isActive
                        ? 'bg-neutral-100 text-neutral-900'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                    }`}
                  >
                    <link.icon size={16} className={isActive ? 'text-amber-500' : 'text-neutral-400'} />
                    {link.name}
                  </Link>
                );
              })}
            </nav>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2 -mr-2 text-neutral-600 hover:text-neutral-900 focus:outline-none"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden overflow-hidden bg-white border-b border-neutral-200 shadow-xl"
            >
              <div className="px-4 py-4 flex flex-col gap-2">
                {navLinks.map((link) => {
                  const isActive = location.pathname === link.path;
                  return (
                    <Link
                      key={link.path}
                      to={link.path}
                      onClick={closeMenu}
                      className={`flex items-center gap-3 px-4 py-3.5 rounded-xl text-base font-semibold transition-colors ${
                        isActive
                          ? 'bg-neutral-100 text-neutral-900'
                          : 'text-neutral-600 hover:bg-neutral-50'
                      }`}
                    >
                      <link.icon size={20} className={isActive ? 'text-amber-500' : 'text-neutral-400'} />
                      {link.name}
                    </Link>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Main Content */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-16">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="h-full"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-neutral-950 text-neutral-400 py-12 md:py-16 mt-auto border-t border-neutral-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-12 lg:gap-16">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-8 h-8 bg-neutral-800 rounded flex items-center justify-center text-white shrink-0">
                  <Hammer size={16} />
                </div>
                <span className="font-bold text-lg text-white uppercase tracking-wider">
                  Vipin Cement Agency
                </span>
              </div>
              <p className="text-sm leading-relaxed max-w-xs">
                Premium local cement and construction material agency. Providing top-quality materials for your strongest builds.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-xs">Contact Us</h4>
              <ul className="space-y-4 text-sm">
                <li className="flex items-start gap-3 group">
                  <Phone size={18} className="text-neutral-500 shrink-0 mt-0.5 group-hover:text-amber-500 transition-colors" />
                  <a href="tel:8239433868" className="hover:text-white transition-colors">8239433868</a>
                </li>
                <li className="flex items-start gap-3 group">
                  <MapPin size={18} className="text-neutral-500 shrink-0 mt-0.5 group-hover:text-amber-500 transition-colors" />
                  <span className="leading-relaxed">
                    [Editable: Shop Address Here]<br />
                    [Editable: City, State, ZIP]
                  </span>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-bold mb-6 uppercase tracking-widest text-xs">Quick Links</h4>
              <ul className="space-y-3 text-sm flex flex-col">
                <Link to="/products" className="hover:text-white transition-colors w-fit">Our Cement</Link>
                <Link to="/price" className="hover:text-white transition-colors w-fit">Current Rates</Link>
                <Link to="/" className="hover:text-white transition-colors w-fit">Find Us</Link>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-neutral-900 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center text-xs">
            <p>&copy; {new Date().getFullYear()} Vipin Cement Agency. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
